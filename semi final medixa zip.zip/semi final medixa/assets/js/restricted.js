// Receptionists Portal JavaScript

// Receptionist Login
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(loginForm);
            const data = {
                email: formData.get('email'),
                password: formData.get('password')
            };
            
            try {
                const response = await fetch('../../api/receptionist_login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Store user data in localStorage
                    localStorage.setItem('receptionist_id', result.user.id);
                    localStorage.setItem('receptionist_name', result.user.name);
                    localStorage.setItem('hospital_name', result.user.hospital);
                    
                    showSuccess('Login successful! Redirecting...');
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 1000);
                } else {
                    showError(result.message || 'Login failed');
                }
            } catch (error) {
                showError('Network error. Please try again.');
                console.error('Login error:', error);
            }
        });
    }
    
    // Receptionist Registration
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(registerForm);
            const password = formData.get('password');
            const confirmPassword = formData.get('confirm_password');
            
            if (password !== confirmPassword) {
                showError('Passwords do not match');
                return;
            }
            
            const data = {
                hospital_name: formData.get('hospital_name'),
                receptionist_name: formData.get('receptionist_name'),
                email: formData.get('email'),
                password: password,
                confirm_password: confirmPassword
            };
            
            try {
                const response = await fetch('../../api/receptionist_register.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showSuccess('Registration successful! Redirecting to login...');
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 1500);
                } else {
                    showError(result.message || 'Registration failed');
                }
            } catch (error) {
                showError('Network error. Please try again.');
                console.error('Registration error:', error);
            }
        });
    }
    
    // Patient Login
    const patientLoginForm = document.getElementById('patientLoginForm');
    if (patientLoginForm) {
        patientLoginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(patientLoginForm);
            const aadhaar = getCleanAadhaar(formData.get('aadhaar'));
            
            const aadhaarValue = formData.get('aadhaar');
            if (!validateAadhaar(aadhaarValue)) {
                showError('Please enter a valid 12-digit Aadhaar number');
                return;
            }
            
            // Check if patient exists in patients table OR demo_aadhaar_data
            try {
                // First check in patients table
                const response = await fetch('../../api/patient_login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ aadhaar: aadhaar })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Store patient data
                    localStorage.setItem('current_patient', JSON.stringify(result.patient));
                    localStorage.setItem('patient_id', result.patient.id);
                    
                    // Display patient details
                    displayPatientDetails(result.patient);
                    showSuccess('Patient login successful!');
                } else {
                    showError(result.message || 'Patient not found');
                }
            } catch (error) {
                showError('Network error. Please try again.');
                console.error('Patient login error:', error);
            }
        });
    }
    
    // Patient Registration
    const patientRegisterForm = document.getElementById('patientRegisterForm');
    if (patientRegisterForm) {
        patientRegisterForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(patientRegisterForm);
            const aadhaar = getCleanAadhaar(formData.get('aadhaar'));
            
            // Check if OTP was verified
            if (!window.tempAadhaarData || !window.tempAadhaar) {
                showError('Please verify OTP first by fetching Aadhaar details');
                return;
            }
            
            // Use the verified Aadhaar
            const verifiedAadhaar = window.tempAadhaar;
            
            const data = {
                aadhaar: verifiedAadhaar,
                name: formData.get('name'),
                date_of_birth: formData.get('date_of_birth'),
                age: parseInt(formData.get('age')),
                gender: formData.get('gender'),
                address: formData.get('address'),
                mobile: formData.get('mobile'),
                scheme: formData.get('scheme'),
                scheme_discount: formData.get('scheme_discount') || '0'
            };
            
            try {
                const response = await fetch('../../api/register_patient.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                const responseText = await response.text();
                let result;
                try {
                    result = JSON.parse(responseText);
                } catch (parseError) {
                    console.error('Invalid JSON response:', responseText.substring(0, 200));
                    throw new Error('Invalid response from server. Please check server logs.');
                }
                
                if (result.success) {
                    showSuccess('Patient registered successfully! Redirecting to login...');
                    // Clear temporary data
                    window.tempAadhaarData = null;
                    window.tempAadhaar = null;
                    
                    // Reset form
                    patientRegisterForm.reset();
                    document.getElementById('patientDetailsContainer').style.display = 'none';
                    document.getElementById('otpContainer').style.display = 'none';
                    
                    // Auto-redirect to login after 2 seconds
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 2000);
                } else {
                    showError(result.message || 'Registration failed');
                }
            } catch (error) {
                showError('Network error: ' + error.message);
                console.error('Patient registration error:', error);
            }
        });
    }
});

// Auto-fetch Aadhaar Details when 12 digits are entered
async function autoFetchAadhaarDetails() {
    const aadhaarInput = document.getElementById('aadhaarInput') || document.querySelector('input[name="aadhaar"]');
    if (!aadhaarInput) return;
    
    const aadhaar = getCleanAadhaar(aadhaarInput.value);
    
    // Only fetch if exactly 12 digits
    if (aadhaar.length !== 12 || !validateAadhaar(aadhaarInput.value)) {
        return;
    }
    
    // Show loading state
    const messageContainer = document.getElementById('message-container');
    if (messageContainer) {
        messageContainer.innerHTML = '<div class="success-message"><i class="fas fa-spinner fa-spin"></i> Fetching patient details and sending OTP...</div>';
    }
    
    try {
        const response = await fetch('../../api/fetch_aadhaar.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ aadhaar: aadhaar })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Show OTP verification first
            document.getElementById('otpContainer').style.display = 'block';
            document.getElementById('patientDetailsContainer').style.display = 'none';
            
            // Update OTP message with mobile number
            const mobileDisplay = document.getElementById('mobileNumberDisplay');
            const otpMessage = document.getElementById('otpMessage');
            if (mobileDisplay && result.data.mobile_number) {
                const mobile = result.data.mobile_number;
                mobileDisplay.innerHTML = `<i class="fas fa-mobile-alt"></i> Mobile: +91 ${mobile.substring(0, 2)}XXXX${mobile.substring(6)}`;
            }
            if (otpMessage && result.message) {
                otpMessage.textContent = result.message;
            }
            
            // Update demo OTP display
            const demoOTP = document.getElementById('demoOTP');
            if (demoOTP && result.otp) {
                demoOTP.textContent = result.otp;
            }
            
            // Store fetched data temporarily (including mobile and scheme)
            window.tempAadhaarData = result.data;
            window.tempAadhaar = aadhaar;
            window.generatedOTP = result.otp || '413256';
            
            // Pre-fill mobile number if available (before OTP verification)
            const mobileInput = document.getElementById('mobileInput') || document.querySelector('input[name="mobile"]');
            if (mobileInput && result.data.mobile_number) {
                mobileInput.value = result.data.mobile_number;
            }
            
            showSuccess('Aadhaar verified! OTP sent to your mobile. Please enter OTP to continue.');
        } else {
            showError(result.message || 'Aadhaar number not found in demo database');
        }
    } catch (error) {
        showError('Network error. Please try again.');
        console.error('Fetch Aadhaar error:', error);
    }
}

// Manual fetch function (for button click if needed)
async function fetchAadhaarDetails() {
    await autoFetchAadhaarDetails();
}

// Verify OTP
function verifyOTP() {
    const otpInput = document.getElementById('otpInput');
    const enteredOTP = otpInput.value.trim();
    const correctOTP = window.generatedOTP || '413256';
    
    if (enteredOTP !== correctOTP) {
        showError(`Invalid OTP. Please enter the correct OTP: ${correctOTP}`);
        return;
    }
    
    // OTP verified, show patient details
    if (window.tempAadhaarData) {
        // Display patient photo if available
        const patientDetailsContainer = document.getElementById('patientDetailsContainer');
        if (patientDetailsContainer) {
            const photoPath = window.tempAadhaarData.photo_path ? `../../${window.tempAadhaarData.photo_path}` : null;
            const photoHtml = photoPath ? `<div style="text-align: center; margin-bottom: 20px;"><img src="${photoPath}" alt="Patient Photo" class="patient-photo" onerror="this.style.display='none'"></div>` : '';
            
            // Insert photo at the beginning of patient details card
            const patientDetailsCard = patientDetailsContainer.querySelector('.patient-details-card');
            if (patientDetailsCard) {
                const existingPhoto = patientDetailsCard.querySelector('.patient-photo');
                if (existingPhoto) {
                    existingPhoto.remove();
                }
                if (photoHtml) {
                    patientDetailsCard.insertAdjacentHTML('afterbegin', photoHtml);
                }
            }
        }
        
        // Fill form fields
        document.querySelector('input[name="name"]').value = window.tempAadhaarData.name || '';
        document.querySelector('input[name="date_of_birth"]').value = window.tempAadhaarData.date_of_birth || '';
        document.querySelector('input[name="age"]').value = window.tempAadhaarData.age || '';
        document.querySelector('input[name="gender"]').value = window.tempAadhaarData.gender || '';
        document.querySelector('textarea[name="address"]').value = window.tempAadhaarData.address || '';
        
        // Auto-fill mobile number
        const mobileInput = document.getElementById('mobileInput') || document.querySelector('input[name="mobile"]');
        if (mobileInput && window.tempAadhaarData.mobile_number) {
            mobileInput.value = window.tempAadhaarData.mobile_number;
        }
        
        // Auto-select scheme if available
        const schemeSelect = document.getElementById('schemeSelect');
        if (schemeSelect && window.tempAadhaarData.scheme) {
            schemeSelect.value = window.tempAadhaarData.scheme;
            
            // Trigger change event to update discount display
            const changeEvent = new Event('change', { bubbles: true });
            schemeSelect.dispatchEvent(changeEvent);
        }
        
        // Hide OTP container and show patient details
        document.getElementById('otpContainer').style.display = 'none';
        document.getElementById('patientDetailsContainer').style.display = 'block';
        
        showSuccess('OTP verified successfully! Patient details and scheme auto-filled. Please review and complete the registration.');
    }
}

// Display Patient Details
function displayPatientDetails(patient) {
    const displayContainer = document.getElementById('patientDetailsDisplay');
    const infoContent = document.getElementById('patientInfoContent');
    
    if (!displayContainer || !infoContent) return;
    
    const photoPath = patient.photo_path ? `../../${patient.photo_path}` : null;
    const photoHtml = photoPath ? `<img src="${photoPath}" alt="Patient Photo" class="patient-photo" onerror="this.style.display='none'">` : '';
    
    infoContent.innerHTML = `
        ${photoHtml}
        <div class="detail-row">
            <span class="detail-label">Name:</span>
            <span class="detail-value">${patient.name}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Aadhaar:</span>
            <span class="detail-value">${formatAadhaar(patient.aadhaar_number)}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Date of Birth:</span>
            <span class="detail-value">${formatDate(patient.date_of_birth)}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Age:</span>
            <span class="detail-value">${patient.age} years</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Gender:</span>
            <span class="detail-value">${patient.gender}</span>
        </div>
        <div class="detail-row">
            <span class="detail-label">Address:</span>
            <span class="detail-value">${patient.address}</span>
        </div>
        ${patient.cause ? `
        <div class="detail-row">
            <span class="detail-label">Cause:</span>
            <span class="detail-value">${patient.cause}</span>
        </div>
        ` : ''}
    `;
    
    displayContainer.style.display = 'block';
    document.getElementById('loginFormContainer').style.display = 'none';
    document.getElementById('registerFormContainer').style.display = 'none';
}

