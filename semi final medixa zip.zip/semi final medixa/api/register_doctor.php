<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $doctor_name = $data['doctor_name'] ?? '';
    $doctor_id = $data['doctor_id'] ?? '';
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    $specialization = $data['specialization'] ?? '';
    
    if (empty($doctor_name) || empty($doctor_id) || empty($email) || empty($password) || empty($specialization)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required']);
        exit;
    }
    
    $conn = getDBConnection();
    
    // Check if doctor ID or email already exists
    $stmt = $conn->prepare("SELECT id FROM doctors WHERE doctor_id = ? OR email = ?");
    $stmt->bind_param("ss", $doctor_id, $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Doctor ID or Email already exists']);
        $stmt->close();
        $conn->close();
        exit;
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new doctor
    $stmt = $conn->prepare("INSERT INTO doctors (doctor_name, doctor_id, email, password, specialization) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $doctor_name, $doctor_id, $email, $hashed_password, $specialization);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Doctor registered successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Registration failed']);
    }
    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>

