<?php
require_once '../config/database.php';
require_once '../helpers/patient_photo_helper.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $aadhaar = $data['aadhaar'] ?? '';
    $aadhaar = preg_replace('/\s+/', '', $aadhaar); // Remove spaces
    
    // Validate Aadhaar: must be exactly 12 digits
    if (empty($aadhaar) || strlen($aadhaar) !== 12 || !preg_match('/^\d{12}$/', $aadhaar)) {
        echo json_encode(['success' => false, 'message' => 'Please enter a valid 12-digit Aadhaar number']);
        exit;
    }
    
    $conn = getDBConnection();
    
    // Check in demo_aadhaar_data table
    $stmt = $conn->prepare("SELECT * FROM demo_aadhaar_data WHERE aadhaar_number = ?");
    $stmt->bind_param("s", $aadhaar);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $data = $result->fetch_assoc();
        
        // Calculate age
        $dob = new DateTime($data['date_of_birth']);
        $today = new DateTime();
        $age = $today->diff($dob)->y;
        
        // Generate OTP (demo: always 413256, in real world this would be sent to mobile)
        $otp = '413256';
        $mobile_number = $data['mobile_number'] ?? 'XXXXXX' . substr($aadhaar, -4); // Masked mobile for demo
        
        // In real implementation, OTP would be sent via SMS API here
        // For demo: OTP is always 413256
        
        // Get scheme from database (if available)
        $scheme = $data['scheme'] ?? null;
        $photo_path = $data['photo_path'] ?? null;
        if (empty($photo_path)) {
            $photo_path = getPatientPhotoPath($aadhaar);
        }
        
        echo json_encode([
            'success' => true,
            'data' => [
                'name' => $data['name'],
                'date_of_birth' => $data['date_of_birth'],
                'age' => $age,
                'gender' => $data['gender'],
                'address' => $data['address'],
                'mobile_number' => $mobile_number,
                'scheme' => $scheme,
                'photo_path' => $photo_path
            ],
            'otp' => $otp,
            'message' => 'OTP has been sent to your Aadhaar linked mobile number ending in ' . substr($mobile_number, -4)
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Aadhaar number not found in demo database']);
    }
    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>

