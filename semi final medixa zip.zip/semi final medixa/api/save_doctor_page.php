<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $data = json_decode(file_get_contents('php://input'), true);
    
    $patient_id = $data['patient_id'] ?? 0;
    $doctor_id = $data['doctor_id'] ?? 0;
    
    // If no doctor_id in data, try session
    if (!$doctor_id && isset($_SESSION['doctor_id'])) {
        $doctor_id = $_SESSION['doctor_id'];
    }
    
    if (!$doctor_id) {
        echo json_encode(['success' => false, 'message' => 'Doctor ID required']);
        exit;
    }
    $records = $data['records'] ?? [];
    
    if (empty($patient_id)) {
        echo json_encode(['success' => false, 'message' => 'Patient ID required']);
        exit;
    }
    
    $conn = getDBConnection();
    
    // Delete existing records for this patient and doctor
    $stmt = $conn->prepare("DELETE FROM doctor_pages WHERE patient_id = ? AND doctor_id = ?");
    $stmt->bind_param("ii", $patient_id, $doctor_id);
    $stmt->execute();
    $stmt->close();
    
    // If no records, just return success (allowing empty records)
    if (empty($records)) {
        $conn->close();
        echo json_encode(['success' => true, 'message' => 'Doctor page cleared successfully']);
        exit;
    }
    
    // Insert new records
    $stmt = $conn->prepare("INSERT INTO doctor_pages (patient_id, doctor_id, symptoms, cause, prescription, test, nurse_instructions, nurse_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    foreach ($records as $record) {
        $symptoms = $record['symptoms'] ?? '';
        $cause = $record['cause'] ?? '';
        $prescription = $record['prescription'] ?? '';
        $test = $record['test'] ?? '';
        $nurse_instructions = '';
        $nurse_status = $record['nurse_status'] ?? 'pending';
        
        if (isset($record['nurse_medicines']) && is_array($record['nurse_medicines'])) {
            $nurse_instructions = implode(', ', $record['nurse_medicines']);
        }
        
        $stmt->bind_param("iissssss", $patient_id, $doctor_id, $symptoms, $cause, $prescription, $test, $nurse_instructions, $nurse_status);
        if (!$stmt->execute()) {
            $stmt->close();
            $conn->close();
            echo json_encode(['success' => false, 'message' => 'Failed to save record: ' . $conn->error]);
            exit;
        }
    }
    
    $stmt->close();
    $conn->close();
    
    echo json_encode(['success' => true, 'message' => 'Doctor page saved successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>

