<?php
require_once '../config/database.php';
require_once '../helpers/patient_photo_helper.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $aadhaar = preg_replace('/\s+/', '', $data['aadhaar'] ?? '');
    
    if (empty($aadhaar) || strlen($aadhaar) !== 12) {
        echo json_encode(['success' => false, 'message' => 'Invalid Aadhaar number']);
        exit;
    }
    
    $conn = getDBConnection();
    
    $stmt = $conn->prepare("SELECT * FROM patients WHERE aadhaar_number = ?");
    $stmt->bind_param("s", $aadhaar);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $patient = $result->fetch_assoc();

        if (empty($patient['photo_path'])) {
            $detectedPhoto = getPatientPhotoPath($patient['aadhaar_number'] ?? '');
            if ($detectedPhoto) {
                $patient['photo_path'] = $detectedPhoto;
                $updateStmt = $conn->prepare("UPDATE patients SET photo_path = ? WHERE id = ?");
                if ($updateStmt) {
                    $updateStmt->bind_param("si", $detectedPhoto, $patient['id']);
                    $updateStmt->execute();
                    $updateStmt->close();
                }
            }
        }
        
        $_SESSION['patient_id'] = $patient['id'];
        $_SESSION['patient_aadhaar'] = $patient['aadhaar_number'];
        
        echo json_encode([
            'success' => true,
            'message' => 'Login successful',
            'patient' => $patient
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Patient not found. Please register first.']);
    }
    
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>

