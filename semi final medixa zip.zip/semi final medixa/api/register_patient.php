<?php
error_reporting(0);
ini_set('display_errors', 0);

session_start();
require_once '../config/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['success' => false, 'message' => 'Invalid JSON data: ' . json_last_error_msg()]);
            exit;
        }
        
        $aadhaar = preg_replace('/\s+/', '', $data['aadhaar'] ?? '');
        $name = $data['name'] ?? '';
        $date_of_birth = $data['date_of_birth'] ?? '';
        $age = $data['age'] ?? '';
        $gender = $data['gender'] ?? '';
        $address = $data['address'] ?? '';
        $mobile = $data['mobile'] ?? '';
        $scheme = $data['scheme'] ?? null;
        $scheme_discount = $data['scheme_discount'] ?? 0;
        $cause = $data['cause'] ?? '';
        $specialization = $data['specialization'] ?? '';
        $doctor_id = $data['doctor_id'] ?? '';
        
        // Validate required fields
        if (empty($aadhaar) || strlen($aadhaar) !== 12) {
            echo json_encode(['success' => false, 'message' => 'Valid 12-digit Aadhaar number is required']);
            exit;
        }
        
        if (empty($name) || empty($date_of_birth) || empty($age) || empty($gender) || empty($address)) {
            echo json_encode(['success' => false, 'message' => 'All patient details are required']);
            exit;
        }
        
        // Check if receptionist is logged in
        if (!isset($_SESSION['receptionist_id'])) {
            echo json_encode(['success' => false, 'message' => 'Please login first']);
            exit;
        }
        
        // Convert empty strings to null for nullable fields
        $scheme = empty($scheme) ? null : $scheme;
        $scheme_discount = empty($scheme_discount) ? 0 : floatval($scheme_discount);
        $cause = empty($cause) ? null : $cause;
        $doctor_id = empty($doctor_id) ? null : intval($doctor_id);
        $specialization = empty($specialization) ? null : $specialization;
        $mobile = empty($mobile) ? null : $mobile;
        
        $conn = getDBConnection();
        
        if (!$conn) {
            echo json_encode(['success' => false, 'message' => 'Database connection failed']);
            exit;
        }
        
        // Get photo_path from demo_aadhaar_data if available
        $photo_path = null;
        $demoStmt = $conn->prepare("SELECT photo_path FROM demo_aadhaar_data WHERE aadhaar_number = ?");
        if ($demoStmt) {
            $demoStmt->bind_param("s", $aadhaar);
            $demoStmt->execute();
            $demoResult = $demoStmt->get_result();
            if ($demoResult->num_rows > 0) {
                $demoData = $demoResult->fetch_assoc();
                $photo_path = $demoData['photo_path'] ?? null;
            }
            $demoStmt->close();
        }
        
        // Check if columns exist, if not add them (with proper error handling)
        try {
            $checkColumns = $conn->query("SHOW COLUMNS FROM patients LIKE 'mobile_number'");
            if ($checkColumns && $checkColumns->num_rows == 0) {
                $conn->query("ALTER TABLE patients ADD COLUMN mobile_number VARCHAR(10) DEFAULT NULL");
            }
            if ($checkColumns) $checkColumns->free();
        } catch (Exception $e) {
            // Column might already exist or table doesn't exist, continue anyway
        }
        
        try {
            $checkColumns = $conn->query("SHOW COLUMNS FROM patients LIKE 'scheme'");
            if ($checkColumns && $checkColumns->num_rows == 0) {
                $conn->query("ALTER TABLE patients ADD COLUMN scheme VARCHAR(50) DEFAULT NULL");
            }
            if ($checkColumns) $checkColumns->free();
        } catch (Exception $e) {
            // Column might already exist, continue anyway
        }
        
        try {
            $checkColumns = $conn->query("SHOW COLUMNS FROM patients LIKE 'scheme_discount'");
            if ($checkColumns && $checkColumns->num_rows == 0) {
                $conn->query("ALTER TABLE patients ADD COLUMN scheme_discount DECIMAL(5,2) DEFAULT 0");
            }
            if ($checkColumns) $checkColumns->free();
        } catch (Exception $e) {
            // Column might already exist, continue anyway
        }
        
        // Check if patient already exists
        $stmt = $conn->prepare("SELECT id FROM patients WHERE aadhaar_number = ?");
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("s", $aadhaar);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Update existing patient
            $patient = $result->fetch_assoc();
            $patient_id = $patient['id'];
            $stmt->close();
            
            // Build UPDATE query dynamically based on available columns
            $updateFields = ["name = ?", "date_of_birth = ?", "age = ?", "gender = ?", "address = ?"];
            $updateValues = [$name, $date_of_birth, $age, $gender, $address];
            $updateTypes = "ssiss";
            
            // Add optional fields if columns exist
            $checkMobile = $conn->query("SHOW COLUMNS FROM patients LIKE 'mobile_number'");
            if ($checkMobile && $checkMobile->num_rows > 0) {
                $updateFields[] = "mobile_number = ?";
                $updateValues[] = $mobile;
                $updateTypes .= "s";
            }
            if ($checkMobile) $checkMobile->free();
            
            $checkScheme = $conn->query("SHOW COLUMNS FROM patients LIKE 'scheme'");
            if ($checkScheme && $checkScheme->num_rows > 0) {
                $updateFields[] = "scheme = ?";
                $updateValues[] = $scheme;
                $updateTypes .= "s";
            }
            if ($checkScheme) $checkScheme->free();
            
            $checkDiscount = $conn->query("SHOW COLUMNS FROM patients LIKE 'scheme_discount'");
            if ($checkDiscount && $checkDiscount->num_rows > 0) {
                $updateFields[] = "scheme_discount = ?";
                $updateValues[] = $scheme_discount;
                $updateTypes .= "d";
            }
            if ($checkDiscount) $checkDiscount->free();
            
            $checkPhoto = $conn->query("SHOW COLUMNS FROM patients LIKE 'photo_path'");
            if ($checkPhoto && $checkPhoto->num_rows > 0 && $photo_path) {
                $updateFields[] = "photo_path = ?";
                $updateValues[] = $photo_path;
                $updateTypes .= "s";
            }
            if ($checkPhoto) $checkPhoto->free();
            
            $updateFields[] = "cause = ?";
            $updateValues[] = $cause;
            $updateTypes .= "s";
            
            $updateFields[] = "assigned_doctor_id = ?";
            $updateValues[] = $doctor_id;
            $updateTypes .= "i";
            
            $updateFields[] = "specialization = ?";
            $updateValues[] = $specialization;
            $updateTypes .= "s";
            
            $updateQuery = "UPDATE patients SET " . implode(", ", $updateFields) . " WHERE id = ?";
            $updateValues[] = $patient_id;
            $updateTypes .= "i";
            
            // Temporarily disable foreign key checks to allow update
            $conn->query("SET FOREIGN_KEY_CHECKS = 0");
            
            $updateStmt = $conn->prepare($updateQuery);
            if (!$updateStmt) {
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");
                throw new Exception("Prepare failed: " . $conn->error . " | Query: " . $updateQuery);
            }
            
            $updateStmt->bind_param($updateTypes, ...$updateValues);
            
            if ($updateStmt->execute()) {
                // Re-enable foreign key checks
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");
                // Update or create registration record
                $receptionist_id = $_SESSION['receptionist_id'];
                // Check if registration exists
                $checkReg = $conn->prepare("SELECT id FROM patient_registrations WHERE patient_id = ? AND receptionist_id = ?");
                if ($checkReg) {
                    $checkReg->bind_param("ii", $patient_id, $receptionist_id);
                    $checkReg->execute();
                    $regResult = $checkReg->get_result();
                    
                    if ($regResult->num_rows > 0) {
                        // Update existing registration
                        $regStmt = $conn->prepare("UPDATE patient_registrations SET registration_date = CURRENT_TIMESTAMP, status = 'active' WHERE patient_id = ? AND receptionist_id = ?");
                        if ($regStmt) {
                            $regStmt->bind_param("ii", $patient_id, $receptionist_id);
                            $regStmt->execute();
                            $regStmt->close();
                        }
                    } else {
                        // Insert new registration
                        $regStmt = $conn->prepare("INSERT INTO patient_registrations (patient_id, receptionist_id, status) VALUES (?, ?, 'active')");
                        if ($regStmt) {
                            $regStmt->bind_param("ii", $patient_id, $receptionist_id);
                            $regStmt->execute();
                            $regStmt->close();
                        }
                    }
                    $checkReg->close();
                }
                
                $updateStmt->close();
                $conn->close();
                echo json_encode(['success' => true, 'message' => 'Patient updated successfully', 'patient_id' => $patient_id]);
            } else {
                // Re-enable foreign key checks even on error
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");
                $error = $conn->error;
                $updateStmt->close();
                $conn->close();
                echo json_encode(['success' => false, 'message' => 'Failed to update patient: ' . $error]);
            }
        } else {
            // Insert new patient
            $stmt->close();
            
            // Build INSERT query dynamically based on available columns
            $insertFields = ["aadhaar_number", "name", "date_of_birth", "age", "gender", "address"];
            $insertValues = [$aadhaar, $name, $date_of_birth, $age, $gender, $address];
            $insertTypes = "sssiss";
            $insertPlaceholders = ["?", "?", "?", "?", "?", "?"];
            
            // Add optional fields if columns exist
            $checkMobile = $conn->query("SHOW COLUMNS FROM patients LIKE 'mobile_number'");
            if ($checkMobile && $checkMobile->num_rows > 0) {
                $insertFields[] = "mobile_number";
                $insertValues[] = $mobile;
                $insertTypes .= "s";
                $insertPlaceholders[] = "?";
            }
            if ($checkMobile) $checkMobile->free();
            
            $checkScheme = $conn->query("SHOW COLUMNS FROM patients LIKE 'scheme'");
            if ($checkScheme && $checkScheme->num_rows > 0) {
                $insertFields[] = "scheme";
                $insertValues[] = $scheme;
                $insertTypes .= "s";
                $insertPlaceholders[] = "?";
            }
            if ($checkScheme) $checkScheme->free();
            
            $checkDiscount = $conn->query("SHOW COLUMNS FROM patients LIKE 'scheme_discount'");
            if ($checkDiscount && $checkDiscount->num_rows > 0) {
                $insertFields[] = "scheme_discount";
                $insertValues[] = $scheme_discount;
                $insertTypes .= "d";
                $insertPlaceholders[] = "?";
            }
            if ($checkDiscount) $checkDiscount->free();
            
            $checkPhoto = $conn->query("SHOW COLUMNS FROM patients LIKE 'photo_path'");
            if ($checkPhoto && $checkPhoto->num_rows > 0 && $photo_path) {
                $insertFields[] = "photo_path";
                $insertValues[] = $photo_path;
                $insertTypes .= "s";
                $insertPlaceholders[] = "?";
            }
            if ($checkPhoto) $checkPhoto->free();
            
            $insertFields[] = "cause";
            $insertValues[] = $cause;
            $insertTypes .= "s";
            $insertPlaceholders[] = "?";
            
            $insertFields[] = "assigned_doctor_id";
            $insertValues[] = $doctor_id;
            $insertTypes .= "i";
            $insertPlaceholders[] = "?";
            
            $insertFields[] = "specialization";
            $insertValues[] = $specialization;
            $insertTypes .= "s";
            $insertPlaceholders[] = "?";
            
            $insertQuery = "INSERT INTO patients (" . implode(", ", $insertFields) . ") VALUES (" . implode(", ", $insertPlaceholders) . ")";
            $insertStmt = $conn->prepare($insertQuery);
            if (!$insertStmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }
            
            $insertStmt->bind_param($insertTypes, ...$insertValues);
            
            if ($insertStmt->execute()) {
                $patient_id = $conn->insert_id;
                
                // Create registration record
                $receptionist_id = $_SESSION['receptionist_id'];
                $regStmt = $conn->prepare("INSERT INTO patient_registrations (patient_id, receptionist_id, status) VALUES (?, ?, 'active')");
                if ($regStmt) {
                    $regStmt->bind_param("ii", $patient_id, $receptionist_id);
                    $regStmt->execute();
                    $regStmt->close();
                }
                
                $insertStmt->close();
                $conn->close();
                echo json_encode(['success' => true, 'message' => 'Patient registered successfully', 'patient_id' => $patient_id]);
            } else {
                $error = $conn->error;
                $insertStmt->close();
                $conn->close();
                echo json_encode(['success' => false, 'message' => 'Failed to register patient: ' . $error]);
            }
        }
    } catch (Exception $e) {
        if (isset($conn) && $conn) {
            $conn->close();
        }
        echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
